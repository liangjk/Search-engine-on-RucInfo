#ifndef getpages_h
#define getpages_h

#include"lock.h"
#ifndef unordered_set_h
	#define unordered_set_h
	#include<unordered_set>
#endif
#ifndef queue_h
	#define queue_h
	#include<queue>
#endif

using namespace std;

void* crawler(void*);

#endif
